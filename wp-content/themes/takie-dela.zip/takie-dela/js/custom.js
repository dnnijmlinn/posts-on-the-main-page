jQuery(document).ready(function($) {
    var page = 1;
    var canLoadMore = true;

    $('#load-more-button').on('click', function() {
        if (canLoadMore) {
            $.ajax({
                url: myAjax.ajaxurl,
                type: 'POST',
                data: {
                    action: 'load_more_posts',
                    page: page,
                },
                success: function(response) {
                    if (response) {
                        $('#post-content').append(response);
                        page++;
                    } else {
                        canLoadMore = false;
                        console.log('No more posts to load.'); // Логирование в консоль
                    }
                },
                error: function(xhr, status, error) {
                    console.error('AJAX error:', error); // Логирование ошибки в консоль
                }
            });
        }
    });
});
