<?php
/**
 * Takie Dela functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Takie_Dela
 */

 function takiedela_enqueue_styles() {
    // Регистрируем файл стилей header.css
    wp_register_style('takiedela-header', get_template_directory_uri() . '/assets/css/header.css', array(), null);
    wp_enqueue_style('takiedela-main-style', get_template_directory_uri() . '/assets/css/main.css', array(), filemtime(get_template_directory() . '/assets/css/main.css'));
    wp_enqueue_style( 'article-style', get_template_directory_uri() . '/assets/css/article.css' );


    // Подключаем файл стилей header.css
    wp_enqueue_style('takiedela-header');
}

// Подключаем функцию takiedela_enqueue_styles к хуку wp_enqueue_scripts, чтобы она выполнялась на фронтенде
add_action('wp_enqueue_scripts', 'takiedela_enqueue_styles');


if ( ! function_exists( 'takie_dela_setup' ) ) :

    function takie_dela_setup() {
        // Добавление поддержки миниатюр записей
        add_theme_support( 'post-thumbnails' );
    }
    
    endif;
    add_action( 'after_setup_theme', 'takie_dela_setup' );
    

    function add_jquery_script() {
        wp_enqueue_script('jquery');
    }
    add_action('wp_enqueue_scripts', 'add_jquery_script');
                  
    function add_custom_js() {
        // Регистрируем скрипт
        wp_register_script('custom-js', get_template_directory_uri() . '/js/custom.js', array('jquery'), null, true);
    
        // Подключаем скрипт на фронтенде
        wp_enqueue_script('custom-js');
    
        // Локализуем переменную ajaxurl для использования в JavaScript
        wp_localize_script('custom-js', 'custom_ajax_obj', array('ajax_url' => admin_url('admin-ajax.php')));
    }
    add_action('wp_enqueue_scripts', 'add_custom_js');
    


    //обработчик кнопки "загрузить еще"
    