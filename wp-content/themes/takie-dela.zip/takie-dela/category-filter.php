<form class="filter filter--category" action="<?php echo site_url('/'); ?>" method="get">
    <div class="filter__input-group">
        <div class="filter__input">
            <label for="date_filter" class="filter__label">Дата публикации</label>
            <div class="filter__datepicker">
                <input type="text" id="date_filter" name="date_filter" class="filter__date" placeholder="">
            </div>
        </div>
        
        <div class="filter__input">
            <label for="category_filter" class="filter__label">Категория</label>
            <div class="filter__select-wrapper">
                <select name="category_filter" id="category_filter" class="filter__date">
                    <option value="" selected> </option>
                    <?php 
                    $categories = get_categories();

                    foreach ($categories as $category) {
                        if ($category->parent == 0) { 
                            echo '<option value="' . $category->term_id . '">' . $category->name . '</option>';
                        }
                    }
                    ?>
                </select>
            </div>
        </div>
    </div>
    <button type="submit" class="filter__button">Применить фильтры</button>
</form>


